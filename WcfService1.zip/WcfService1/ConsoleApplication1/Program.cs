﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            // ServiceReference1.IRestaurant ss = new ServiceReference1.
            var d = new ServiceReference1.Service1Client();
            var r = new ServiceReference1.Restaurant();
            var rev = new ServiceReference1.Review();
            
            r.Address1 = "ddd";
            r.Address2 = "dddd";
            r.State = "DD";
            r.Zip = "11222-2222";
            r.Phone = "444-444-4444";
            r.City = "sssssss";
            r.Name = "dddddddd";
            r.URL = "www.google.com";
            rev.Rating = 3;
            rev.RestaurantId = 1;
            rev.ReviewDate = DateTime.Now;
            rev.UserId = 1;
            rev.Review1 = "This is a test";
            
            bool ddd = d.PostReview(rev);
            ddd = d.PostRestaurant(r);
            ddd = d.DeleteReview(2);
            Console.WriteLine(ddd);
            string d1 = d.ReviewListByUser(ServiceReference1.ReturnFormat.JSON, 1);
            string d2 = d.GetRestaurantsByCity(ServiceReference1.ReturnFormat.JSON, r.City,r.State);
            Console.WriteLine(d1);
            Console.WriteLine();
            Console.WriteLine(d2);
            Console.Read();

        }
    }
}
