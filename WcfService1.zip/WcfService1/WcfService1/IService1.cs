﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        bool PostReview(Review review);

        [OperationContract]
        bool DeleteReview(long id);

        [OperationContract]
        string ReviewListByUser(ReturnFormat format, long UserId);

        [OperationContract]
        string GetRestaurantsByCity(ReturnFormat format, string city, string state);

        [OperationContract]
        bool PostRestaurant(Restaurant restaurant);


    }
    [DataContract]
    public enum ReturnFormat
    {
        [EnumMember]
        XML,
        [EnumMember]
        JSON
    }
}
