﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using WcfService1.Interface;

namespace WcfService1
{
    public class Service1 : IService1
    {
        public bool DeleteReview(long id)
        {
            using (var restaurantDBContext = new RestaurantDBContext())
            {
                var d = restaurantDBContext.Reviews.Find(id);
                restaurantDBContext.Reviews.Remove(d);
                return restaurantDBContext.SaveChanges() > 0;
            }
        }

        public bool PostReview(Review review)
        {
            try
            {
                using (var restaurantDBContext = new RestaurantDBContext())
                {
                    restaurantDBContext.Reviews.Add(review);
                    return restaurantDBContext.SaveChanges() > 0;
                }
            }
            catch (Exception)
            {

                return false;
            }
        }

        public string ReviewListByUser(ReturnFormat format, long UserId)
        {
            try
            {
                using (var restaurantDBContext = new RestaurantDBContext())
                {
                    var x = restaurantDBContext.vwUserReviews.Where(d => d.UserId == UserId).OrderByDescending(d => d.ReviewDate).ThenBy(d => d.Name).ToList();
                    ReviewList rvl = new ReviewList(x);
                    ISerialize _Serialize = new UnityContainer().LoadConfiguration().Resolve<ISerialize>(format.ToString());
                    return _Serialize.Serialize<ReviewList>(rvl);
                }
            }
            catch (Exception)
            {

                return "";
            }
        }
        public string GetRestaurantsByCity(ReturnFormat format, string city, string state)
        {
            try
            {
                using (var restaurantDBContext = new RestaurantDBContext())
                {
                    var x = restaurantDBContext.vwRestaurants.Where(d => d.City == city && d.State == state).OrderBy(d=>d.Name).ToList();
                    RestaurantList rl = new RestaurantList(x);
                    ISerialize _Serialize = new UnityContainer().LoadConfiguration().Resolve<ISerialize>(format.ToString());
                    return _Serialize.Serialize<RestaurantList>(rl);
                }
            }
            catch (Exception)
            {
                return "";
            }

        }

        public bool PostRestaurant(Restaurant restaurant)
        {
            try
            {
                using (var restaurantDBContext = new RestaurantDBContext())
                {
                    var x = restaurantDBContext.Restaurants.Where(d => d.Name == restaurant.Name && d.Zip == restaurant.Zip).ToList();
                    if (x.Count == 0)
                    {
                        restaurantDBContext.Restaurants.Add(restaurant);
                        return restaurantDBContext.SaveChanges() > 0;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
