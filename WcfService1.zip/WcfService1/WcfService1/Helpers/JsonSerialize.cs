﻿using WcfService1.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Serialization;
using System.Web;
using System.Xml;
using System.Xml.Serialization;
using System.Reflection;
using System.ComponentModel;
using System.Globalization;
using System.Resources;
using System.Linq;
using System.Text;


namespace WcfService1.Helpers
{
    public class JsonSerialization : ISerialize
    {
        public string Serialize<T>( object objectGraph )
        {
            if ( objectGraph == null ) throw new ArgumentNullException("object is null.");
            
            try
            {
                string json = JsonConvert.SerializeObject((T)objectGraph);
                return json;
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create json string from object", ex);
            }
        }

        public string Serialize<T>( object objectGraph, Type[] extraTypes )
        {
            if ( objectGraph == null ) throw new ArgumentNullException("object is null.");
            
            try
            {
                string json = JsonConvert.SerializeObject((T)objectGraph);
                return json;
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create json string from object", ex);
            }
        }

        public string Serialize<T>( string filepath, object objectGraph, bool append )
        {
            if ( string.IsNullOrEmpty(filepath) ) throw new ArgumentNullException("filepath is null or empty.");
            
            if ( objectGraph == null ) throw new ArgumentNullException("object is null.");
            
            try
            {
                string json = JsonConvert.SerializeObject((T)objectGraph);
                using ( StreamWriter stream = new StreamWriter(filepath, append) )
                {
                    stream.Write(json);
                    return json;
                }
            }
            catch ( FieldAccessException ex )
            {
                throw new FieldAccessException("Either Directory don't exists or no permission", ex);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from json string", ex);
            }
        }

        public string Serialize<T>( string filepath, object objectGraph, Type[] extraTypes, bool append )
        {
            if ( string.IsNullOrEmpty(filepath) ) throw new ArgumentNullException("filepath is null or empty.");

            if ( objectGraph == null ) throw new ArgumentNullException("object is null.");

            try
            {
                string json = JsonConvert.SerializeObject((T)objectGraph);
                using ( StreamWriter stream = new StreamWriter(filepath, append) )
                {
                    stream.Write(json);
                    return json;
                }
            }
            catch ( FieldAccessException ex )
            {
                throw new FieldAccessException("Either Directory don't exists or no permission", ex);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from json string", ex);
            }
        }

        public T Deserialize<T>( HttpContext context )
        {
            if ( context == null ) throw new ArgumentNullException("context is null.");
            
            try
            {
                //read the json string
                string jsonData = new StreamReader(context.Request.InputStream).ReadToEnd();

                //cast to specified objectType
                var obj = Deserialize<T>(jsonData);

                //return the object
                return obj;
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from HttpContext", ex);
            }
        }

        public T Deserialize<T>( string value )
        {
            if ( string.IsNullOrEmpty(value) ) throw new ArgumentNullException("value is null or empty.");
            
            try
            {
                //cast to specified objectType
                var obj = JsonConvert.DeserializeObject<T>(value);

                //return the object
                return obj;
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from json string", ex);
            }
        }

        public void BinarySerializeToFile( object objectGraph, string filepath )
        {
            if ( objectGraph == null ) throw new ArgumentNullException("object is null.");
            if ( string.IsNullOrEmpty(filepath) ) throw new ArgumentNullException("filepath is null or empty.");
            
            try
            {
                if ( !File.Exists(filepath) ) throw new FileNotFoundException("filepath not found");

                string json = JsonConvert.SerializeObject(objectGraph);

                byte[] byteArray = Encoding.ASCII.GetBytes(json);
                using ( StreamWriter stream = new StreamWriter(filepath, false) )
                {
                    stream.Write(byteArray);
                }
            }
            catch ( FieldAccessException ex )
            {
                throw new FieldAccessException("Either Directory don't exists or no permission", ex);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from json string", ex);
            }

        }

        public T DeserializeFromFile<T>( string filepath )
        {
            if ( string.IsNullOrEmpty(filepath) ) throw new ArgumentNullException("filepath is null or empty.");

            try
            {
                if ( !File.Exists(filepath) ) throw new FileNotFoundException("filepath not found");

                using ( StringReader stream = new StringReader(filepath) )
                {
                    string json = stream.ReadToEnd();
                    try
                    {
                        return (T)Deserialize<T>(json);
                    }
                    catch ( Exception ex )
                    {
                        throw new InvalidOperationException("Failed to create object from json string", ex);
                    }
                }
            }
            catch ( FieldAccessException ex )
            {
                throw new FieldAccessException("Either Directory don't exists or no permission", ex);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from json string", ex);
            }
        }

        public T DeserializeFromBinaryFile<T>( string filepath )
        {
            if ( string.IsNullOrEmpty(filepath) ) throw new ArgumentNullException("filepath is null or empty.");

            try
            {
                if ( !File.Exists(filepath) ) throw new FileNotFoundException("filepath not found");

                XmlSerializer serializer = new XmlSerializer(typeof(T));
                using ( MemoryStream stream = new MemoryStream() )
                {
                    using ( FileStream file = new FileStream(filepath, FileMode.Open, FileAccess.Read) )
                    {
                        byte[] bytes = new byte[ file.Length ];
                        string json = Encoding.ASCII.GetString(bytes);
                        return Deserialize<T>(json);
                    }
                }
            }
            catch ( FieldAccessException ex )
            {
                throw new FieldAccessException("Either Directory don't exists or no permission", ex);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from json string", ex);
            }
        }
    }
}