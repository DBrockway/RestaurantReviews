﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization;
using System.Reflection;
using System.ComponentModel;
using System.Globalization;
using System.Resources;
using System.Linq;
using System.Xml;
using WcfService1.Interface;
using System.Web;

namespace WcfService1.Helpers
{
    public class XMLSerialization : ISerialize
    {
        public string Serialize<T>( object objectGraph )
        {
            if ( objectGraph == null ) throw new ArgumentNullException("object is null.");

            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));

                using ( StringWriter stream = new StringWriter() )
                {
                    XmlSerializerNamespaces xsn = new XmlSerializerNamespaces();

                    xsn.Add(string.Empty, string.Empty);
                    serializer.Serialize(stream, objectGraph, xsn);
                    stream.Flush();
                    string[] lines = stream.ToString().Split(Environment.NewLine.ToCharArray()).Skip(1).ToArray();

                    return string.Join("", lines);
                }
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create XML string from object", ex);
            }
        }

        public string Serialize<T>( object objectGraph, Type[] extraTypes )
        {
            if ( objectGraph == null ) throw new ArgumentNullException("object is null.");

            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T), extraTypes);
                using ( StringWriter stream = new StringWriter() )
                {
                    XmlSerializerNamespaces xsn = new XmlSerializerNamespaces();
                    xsn.Add(string.Empty, string.Empty);
                    serializer.Serialize(stream, objectGraph, xsn);
                    stream.Flush();
                    string[] lines = stream.ToString().Split(Environment.NewLine.ToCharArray()).Skip(1).ToArray();

                    return string.Join("", lines);
                }
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create XML string from object", ex);
            }
        }

        public string Serialize<T>( string filepath, object objectGraph, bool append )
        {
            if ( string.IsNullOrEmpty(filepath) ) throw new ArgumentNullException("filepath is null or empty.");

            if ( objectGraph == null ) throw new ArgumentNullException("object is null.");

            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                using ( StreamWriter stream = new StreamWriter(filepath, append) )
                {
                    XmlSerializerNamespaces xsn = new XmlSerializerNamespaces();
                    xsn.Add(string.Empty, string.Empty);
                    serializer.Serialize(stream, objectGraph, xsn);
                    stream.Flush();
                    stream.Close();
                    string[] lines = stream.ToString().Split(Environment.NewLine.ToCharArray()).Skip(1).ToArray();
                    return string.Join("", lines);
                }
            }
            catch ( FieldAccessException ex )
            {
                throw new FieldAccessException("Either Directory don't exists or no permission", ex);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create XML file from object", ex);
            }
        }

        public string Serialize<T>( string filepath, object objectGraph, Type[] extraTypes, bool append )
        {
            if ( string.IsNullOrEmpty(filepath) ) throw new ArgumentNullException("filepath is null or empty.");

            if ( objectGraph == null ) throw new ArgumentNullException("object is null.");

            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T), extraTypes);
                using ( StreamWriter stream = new StreamWriter(filepath, append) )
                {
                    XmlSerializerNamespaces xsn = new XmlSerializerNamespaces();
                    xsn.Add(string.Empty, string.Empty);
                    serializer.Serialize(stream, objectGraph, xsn);
                    stream.Flush();
                    stream.Close();
                    string[] lines = stream.ToString().Split(Environment.NewLine.ToCharArray()).Skip(1).ToArray();
                    return string.Join("", lines);
                }
            }
            catch ( FieldAccessException ex )
            {
                throw new FieldAccessException("Either Directory don't exists or no permission", ex);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create XML file from object", ex);
            }
        }

        public T Deserialize<T>( HttpContext context )
        {
            if ( context == null ) throw new ArgumentNullException("context is null.");

            try
            {
                string xml = new StreamReader(context.Request.InputStream).ReadToEnd();
                return Deserialize<T>(xml);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from XML HttpContext", ex);
            }
        }

        public T Deserialize<T>( string value )
        {
            if ( string.IsNullOrEmpty(value) )
            {
                throw new ArgumentNullException("value is null or empty.");
            }

            XmlSerializer serializer = new XmlSerializer(typeof(T));
            using ( StringReader stream = new StringReader(value) )
            {
                try
                {
                    return (T)serializer.Deserialize(stream);
                }
                catch ( Exception ex )
                {
                    // The serialization error messages are cryptic at best.
                    // Give a hint at what happened
                    throw new InvalidOperationException("Failed to create object from xml string", ex);
                }
            }
        }

        public void BinarySerializeToFile<T>( object objectGraph, string filepath )
        {
            if ( objectGraph == null ) throw new ArgumentNullException("object is null.");
            if ( string.IsNullOrEmpty(filepath) ) throw new ArgumentNullException("filepath is null or empty.");

            try
            {
                string basepath = System.IO.Path.GetDirectoryName(filepath);
                if ( !System.IO.Directory.Exists(basepath) )
                {
                    System.IO.Directory.CreateDirectory(basepath);
                }


                using ( Stream stream = new FileStream(filepath, System.IO.FileMode.Create) )
                {
                    IFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    formatter.Serialize(stream, objectGraph);
                }
            }
            catch ( FieldAccessException ex )
            {
                throw new FieldAccessException("Either Directory don't exists or no permission", ex);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from xml string", ex);
            }
        }

        public T DeserializeFromFile<T>( string filepath )
        {
            if ( string.IsNullOrEmpty(filepath) ) throw new ArgumentNullException("filepath is null or empty.");

            try
            {
                XmlDocument xDoc = new XmlDocument();
                xDoc.Load(filepath);

                XmlSerializer serializer = new XmlSerializer(typeof(T));
                using ( StringReader stream = new StringReader(xDoc.OuterXml) )
                {
                    return (T)serializer.Deserialize(stream);
                }
            }
            catch ( FieldAccessException ex )
            {
                throw new FieldAccessException("Either Directory don't exists or no permission", ex);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from xml string", ex);
            }
        }

        public T DeserializeFromBinaryFile<T>( string filepath )
        {
            if ( string.IsNullOrEmpty(filepath) ) throw new ArgumentNullException("Invalid filepath.");

            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                using ( MemoryStream stream = new MemoryStream() )
                {
                    using ( FileStream file = new FileStream(filepath, FileMode.Open, FileAccess.Read) )
                    {
                        byte[] bytes = new byte[ file.Length ];
                        file.Read(bytes, 0, (int)file.Length);
                        stream.Write(bytes, 0, (int)file.Length);
                        XmlDocument xDoc = new XmlDocument();
                        IFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                        return (T)serializer.Deserialize(stream);
                    }
                }
            }
            catch ( FieldAccessException ex )
            {
                throw new FieldAccessException("Either Directory don't exists or no permission", ex);
            }
            catch ( Exception ex )
            {
                throw new InvalidOperationException("Failed to create object from xml string", ex);
            }
        }
    }
}