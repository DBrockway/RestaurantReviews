namespace WcfService1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Review")]
    public partial class Review
    {
        public int Id { get; set; }

        public int? RestaurantId { get; set; }

        public int? UserId { get; set; }

        public DateTime? ReviewDate { get; set; }

        [Column("Review")]
        [StringLength(2000)]
        public string Review1 { get; set; }

        public int? Rating { get; set; }

        public virtual Restaurant Restaurant { get; set; }

        public virtual UserTable UserTable { get; set; }
    }
}
