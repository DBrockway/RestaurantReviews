namespace WcfService1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Xml;
    using System.Xml.Serialization;
    using Newtonsoft.Json;

    [Table("vwUserReview")]
    public partial class vwUserReview
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [XmlIgnore]
        [JsonIgnore]
        public int Expr1 { get; set; }

        [StringLength(100)]
        public string Username { get; set; }

        [StringLength(255)]
        public string Email { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        public int? RestaurantId { get; set; }

        public int? UserId { get; set; }

        public DateTime? ReviewDate { get; set; }

        [StringLength(2000)]
        public string Review { get; set; }

        public int? Rating { get; set; }

        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(80)]
        public string Address1 { get; set; }

        [StringLength(80)]
        public string Address2 { get; set; }

        [StringLength(50)]
        public string City { get; set; }

        [StringLength(2)]
        public string State { get; set; }

        [StringLength(10)]
        public string Zip { get; set; }

        [StringLength(20)]
        public string Phone { get; set; }

        [StringLength(255)]
        public string URL { get; set; }
    }
}
