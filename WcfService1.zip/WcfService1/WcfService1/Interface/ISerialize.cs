﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Serialization;

namespace WcfService1.Interface
{
   
    interface ISerialize
    {

        /// <summary>
        /// Serialize object
        /// </summary>
        /// <typeparam name="T">Class Type</typeparam>
        /// <param name="objectGraph">Contant of an Object T</param>
        /// <returns>String</returns>
        string Serialize<T>( object objectGraph );

        /// <summary>
        /// Serialize Object
        /// </summary>
        /// <typeparam name="T">Class Type</typeparam>
        /// <param name="objectGraph">Contant of an Object T</param>
        /// <param name="extraTypes">Extra Types to Serialize (Not used for JSON)</param>
        /// <returns></returns>
        string Serialize<T>( object objectGraph, Type[] extraTypes );

        /// <summary>
        /// Serialize to a File 
        /// </summary>
        /// <typeparam name="T">Class Type</typeparam>
        /// <param name="filePath">Filename to create or Append</param>
        /// <param name="objectGraph">Contant of an Object T</param>
        /// <param name="append">Append to an existing file</param>
        /// <returns>String</returns>
        string Serialize<T>( string filepath, object objectGraph, bool append );

        /// <summary>
        /// Serialize to a File 
        /// </summary>
        /// <typeparam name="T">Class Type</typeparam>
        /// <param name="filePath">Filename to create or Append</param>
        /// <param name="objectGraph">Contant of an Object T</param>
        /// <param name="append">Append to an existing file</param>
        /// <returns>String</returns>
        string Serialize<T>( string filepath, object objectGraph, Type[] extraTypes, bool append );

        T Deserialize<T>( HttpContext context );

        /// <summary>
        /// DeSerialize a string
        /// </summary>
        /// <typeparam name="T">Class Type</typeparam>
        /// <param name="value">string that will be deserialize</param>
        /// <returns></returns>
        T Deserialize<T>( string value );

        /// <summary>
        /// Deserialize a file
        /// </summary>
        /// <typeparam name="T">Class Type</typeparam>
        /// <param name="filePath"></param>
        /// <returns>Object</returns>
        T DeserializeFromFile<T>( string filepath );

        /// <summary>
        /// Deserialize a binary file
        /// </summary>
        /// <typeparam name="T">Class Type</typeparam>
        /// <param name="filePath"></param>
        /// <returns>Object</returns>
        T DeserializeFromBinaryFile<T>( string filepath );

    }

}
