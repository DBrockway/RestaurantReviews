﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace WcfService1
{
    /// <summary>
    /// Used for format output
    /// </summary>
    public class ReviewList
    {
        [XmlElement(ElementName = "Review")]
        public List<vwUserReview> Reviews { get; set; }
        public ReviewList() { }
        public ReviewList(List<vwUserReview> reviews)
        {
            this.Reviews = reviews;
        }
    }
    public class RestaurantList
    {
        [XmlElement(ElementName = "Restautant")]
        public List<vwRestaurant> Restaurants { get; set; }

        public RestaurantList() { }
        public RestaurantList(List<vwRestaurant> restautants)
        {
            this.Restaurants = restautants;
        }
    }
}