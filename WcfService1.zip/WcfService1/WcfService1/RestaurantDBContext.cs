namespace WcfService1
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class RestaurantDBContext : DbContext
    {
        public RestaurantDBContext()
            : base("name=RestaurantDBContext")
        {
        }

        public virtual DbSet<Restaurant> Restaurants { get; set; }
        public virtual DbSet<Review> Reviews { get; set; }
        public virtual DbSet<sysdiagram> sysdiagrams { get; set; }
        public virtual DbSet<UserTable> UserTables { get; set; }
        public virtual DbSet<vwRestaurant> vwRestaurants { get; set; }
        public virtual DbSet<vwUserReview> vwUserReviews { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserTable>()
                .HasMany(e => e.Reviews)
                .WithOptional(e => e.UserTable)
                .HasForeignKey(e => e.UserId);
        }
    }
}
